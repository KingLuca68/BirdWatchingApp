### Introduction
Welcome to the Chirp App, an Android application built with Kotlin for avid bird watchers. Whether you're an experienced birder or a beginner, this app provides a comprehensive toolset to enhance your bird-watching experience. Track your bird sightings, explore current bird-watching hotspots, and get detailed directions to those locations. You can also securely add notes, place markers for sightings, and keep a detailed log of your bird-watching activities, all in one place. The app is designed to offer birders an organized, user-friendly experience while connecting them to their passion for birdwatching.

### Features
- Login & registration
- Settings
- View nearby birding hotspots
- View best route to hotspots
- View user's current location
- Select a hotspot
- Add marker for bird sighting

### Step-by-step

Quick Start Guide:
Download the Chirp Source Code: Begin by downloading the source code from the project repository (see the Project Link section below).

Run the App in Android Studio: Open the project in Android Studio and run it on the provided emulator or an Android device.

Log In or Sign Up: On the login page, you can either sign in with an existing account or create a new one by clicking the "Sign Up" link.
For demonstration purposes, you can use the following demo account:

Email: Demo20@gmail.com
Password: QweRTY.123

Register Your Account: If signing up, provide your email and create a secure password. Once registered, you'll be redirected to the login page to access your account.

Explore the App: After logging in, you’ll be taken to the home page, where you’ll find two main features:

Settings: Adjust your preferences, including filtering bird hotspots by distance and toggling between metric (km) and imperial (miles) units.

Hotspots: Access the map feature to view nearby bird hotspots, track your location, get directions, and mark sightings of birds.

### Contact
Feel free to contact me at [email@example.com](mailto:email@example.com).

Project Link:
GitHub : [https://github.com/username/project-name](https://github.com/username/project-name)

YouTube : 
