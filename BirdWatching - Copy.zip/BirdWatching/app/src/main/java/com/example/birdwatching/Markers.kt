package com.example.birdwatching

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Markers : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_markers)
    }
}